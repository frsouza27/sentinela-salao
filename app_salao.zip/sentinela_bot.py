import sqlite3
import pywhatkit as kit
import time
from datetime import datetime, timedelta

DB_NAME = 'salao_sentinela.db'
LINK_REAGENDAMENTO = "https://seu-site-salao.streamlit.app" # Substitua pelo seu link real

def executar_query(query, params=(), fetch=False):
    """Função auxiliar para centralizar a segurança do banco."""
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        conn.commit()
        if fetch:
            return cursor.fetchall()

def preparar_banco():
    # Garante que as colunas existam sem quebrar o código
    try:
        executar_query("ALTER TABLE agendamentos ADD COLUMN horario_envio TEXT")
        executar_query("ALTER TABLE agendamentos ADD COLUMN status TEXT DEFAULT 'pendente'")
    except:
        pass 

def disparar_avisos():
    data_alvo = (datetime.now() + timedelta(days=2)).strftime('%Y-%m-%d')
    proximos = executar_query("""
        SELECT id, cliente, telefone, servico, hora 
        FROM agendamentos WHERE data = ? AND enviado = 0
    """, (data_alvo,), fetch=True)
    
    agora_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    for agendamento in proximos:
        idx, nome, tel, servico, hora = agendamento
        num_zap = "+55" + "".join(filter(str.isdigit, tel))
        
        msg = (f"Olá {nome}! 🌹 Confirmando seu horário de {servico} para {hora}. "
               "Responda em até 6h para garantir sua vaga. "
               "Caso não responda, o sistema cancelará para liberar a agenda. Obrigada!")
        
        try:
            print(f"Enviando confirmação para {nome}...")
            kit.sendwhatmsg_instantly(num_zap, msg, wait_time=15, tab_close=True)
            
            executar_query("""
                UPDATE agendamentos SET enviado = 1, horario_envio = ?, status = 'aguardando_confirmacao' 
                WHERE id = ?
            """, (agora_str, idx))
            time.sleep(10)
        except Exception as e:
            print(f"Erro no envio: {e}")

def verificar_expiracao():
    pendentes = executar_query("SELECT id, cliente, telefone, horario_envio FROM agendamentos WHERE status = 'aguardando_confirmacao'", fetch=True)
    agora = datetime.now()
    
    for idx, nome, tel, h_envio in pendentes:
        horario_limite = datetime.strptime(h_envio, '%Y-%m-%d %H:%M:%S') + timedelta(hours=6)
        
        if agora > horario_limite:
            print(f"⏰ Cancelando vaga de {nome}...")
            executar_query("UPDATE agendamentos SET status = 'cancelado' WHERE id = ?", (idx,))
            
            # ENVIO DO LINK DE CANCELAMENTO (BACKEND AUTOMÁTICO)
            num_zap = "+55" + "".join(filter(str.isdigit, tel))
            msg_cancelamento = (f"Olá {nome}, seu horário foi cancelado por falta de confirmação. 🌸 "
                                f"Para agendar novamente, acesse: {LINK_REAGENDAMENTO}")
            try:
                kit.sendwhatmsg_instantly(num_zap, msg_cancelamento, wait_time=15, tab_close=True)
                time.sleep(10)
            except:
                pass

if __name__ == "__main__":
    preparar_banco()
    disparar_avisos()
    verificar_expiracao()